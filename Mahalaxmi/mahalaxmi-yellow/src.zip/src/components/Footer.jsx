import React, { useState } from "react";
import "../styles/Footer.css";
import { FaWhatsapp, FaFacebookF, FaTwitter, FaInstagram } from "react-icons/fa";
import { Link } from "react-router-dom";

const Footer = () => {
  const [email, setEmail] = useState("");

  const handleSubscribe = () => {
    if (email) {
      alert(`Thank you for subscribing: ${email}`);
      setEmail(""); // Clear input after submission
    } else {
      alert("Please enter a valid email address");
    }
  };

  return (
    <footer className="footer">
      <div className="footer-row">
        {/* Column 1: Brand + Description + Social */}
        <div className="footer-col">
          <h1>MAHALAXMI</h1>
          <p>
            Whether you're a home baker, a health enthusiast, or a modern
            homemaker, our flour mills are designed to suit every lifestyle.
            Experience the perfect blend of tradition and technology.
          </p>
          <div className="social-icons">
            <a href="#"><FaWhatsapp /></a>
            <a href="https://m.facebook.com/mahalaxmichakki/"><FaFacebookF /></a>
            <a href="#"><FaTwitter /></a>
            <a href="https://www.instagram.com/mahalaxmiAttachakki_offical?igsh=ZnRycm1iMzZ6bmFm"><FaInstagram /></a>
          </div>
        </div>

        {/* Column 2: Customer Support */}
        <div className="footer-col">
          <h3>Customer Support</h3>
          <ul>
            <li>Our Story</li>
            <li>Mission And Values</li>
            <li>
              <Link to="/about#team" style={{ color: 'inherit', textDecoration: 'none' }}>
                Meet the Team
              </Link>
            </li>
            <li>Brand Partnership</li>
            <li>
              <Link to="/contact">Contact Us</Link>
            </li>
          </ul>
        </div>

        {/* Column 3: Policies */}
        <div className="footer-col">
          <h3>Accessibility & Policies</h3>
          <ul>
            <li>Accessibility Statement</li>
            <li>Sitemap</li>
            <li>Privacy Policy</li>
            <li>Terms & Conditions</li>
            <li>Goods</li>
          </ul>
        </div>

        {/* Column 4: Newsletter */}
        <div className="footer-col">
          <h3>Stay Updated</h3>
          <p>
            Sign up to get first dibs on new arrivals, sales, exclusive content,
            events, and more!
          </p>
          <div className="newsletter">
            <input
              type="email"
              placeholder="Enter Your Email Address..."
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <button onClick={handleSubscribe}>→</button>
          </div>
        </div>
      </div>

      {/* Footer bottom */}
      <div className="footer-bottom">
        <p>©2025 All Rights Reserved By Mahalaxmi. Designed by Noble Tech</p>
      </div>
    </footer>
  );
};

export default Footer;
