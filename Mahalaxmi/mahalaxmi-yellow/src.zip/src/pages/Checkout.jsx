import React, { useEffect, useMemo, useState } from "react";
import "../styles/Checkout.css";
import { useNavigate } from "react-router-dom";
import { useCart } from "../context/CartContext";
import QRCode from "qrcode"; // ✅ use qrcode instead of react-qr-code

const Checkout = () => {
  const navigate = useNavigate();
  const { cart } = useCart();

  const [paymentMethod, setPaymentMethod] = useState("cod");
  const [customerUpiId, setCustomerUpiId] = useState(""); // only for records
  const [qrSrc, setQrSrc] = useState("");

  // ✅ Your shop UPI ID (static)
  const shopUpiId = "yourshop@upi"; // replace with your real UPI ID

  // Robust number sanitizer
  const toNumber = (v) => {
    if (typeof v === "number") return v;
    const n = parseFloat(String(v).replace(/[^\d.]/g, ""));
    return Number.isFinite(n) ? n : 0;
  };

  const totalPrice = cart.reduce(
    (total, item) =>
      total + toNumber(item.price) * (Number(item.quantity) || 0),
    0
  );

  const formatINR = (n) =>
    toNumber(n).toLocaleString("en-IN", { maximumFractionDigits: 2 });

  const handleSubmit = (e) => {
    e.preventDefault();

    if (paymentMethod === "cod") {
      alert("Order placed ✅\nPayment Method: Cash on Delivery");
      navigate("/");
    } else if (paymentMethod === "card") {
      alert("Card payment processing is not implemented in this version.");
      navigate("/");
    } else if (paymentMethod === "upi") {
      if (!customerUpiId) {
        alert("Please enter your UPI ID (for records).");
        return;
      }
      alert("Please complete the payment using the QR code or UPI app links.");
    }
  };

  // ✅ Generate UPI link (always goes to shop’s UPI ID)
  const upiLink = useMemo(() => {
    return `upi://pay?pa=${encodeURIComponent(
      shopUpiId
    )}&pn=${encodeURIComponent("My Shop")}&am=${toNumber(totalPrice)}&cu=INR`;
  }, [shopUpiId, totalPrice]);

  // Generate QR code dynamically
  useEffect(() => {
    if (paymentMethod === "upi") {
      QRCode.toDataURL(upiLink)
        .then((url) => setQrSrc(url))
        .catch((err) => console.error("QR Generation Error:", err));
    } else {
      setQrSrc("");
    }
  }, [upiLink, paymentMethod]);

  const copy = async (text, label = "Copied!") => {
    try {
      await navigator.clipboard.writeText(text);
      alert(label);
    } catch {
      // Fallback
      const ta = document.createElement("textarea");
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      alert(label);
    }
  };

  return (
    <div className="checkout-wrapper">
      {/* Left Side */}
      <div className="checkout-left">
        <div className="checkout-container">
          <h1 className="checkout-title">Checkout</h1>

          <form onSubmit={handleSubmit}>
            {/* Payment Methods */}
            <div className="payment-methods">
              <h2>Select Payment Method</h2>

              <label className="payment-option">
                <input
                  type="radio"
                  name="payment"
                  value="cod"
                  checked={paymentMethod === "cod"}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                />
                <span className="radio-label cod-label">💵 Cash on Delivery</span>
              </label>

              <label className="payment-option">
                <input
                  type="radio"
                  name="payment"
                  value="card"
                  checked={paymentMethod === "card"}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                />
                <span className="radio-label">💳 Debit / Credit Card</span>
              </label>

              <label className="payment-option">
                <input
                  type="radio"
                  name="payment"
                  value="upi"
                  checked={paymentMethod === "upi"}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                />
                <span className="radio-label">📱 UPI</span>
              </label>
            </div>

            {/* Conditional Payment Fields */}
            {paymentMethod === "card" && (
              <div className="checkout-section">
                <h3>Enter Card Details</h3>
                <input
                  type="text"
                  className="checkout-input"
                  placeholder="Card Number"
                  pattern="[0-9]{16}"
                  maxLength="16"
                  required
                />
                <div className="input-row">
                  <input
                    type="text"
                    className="checkout-input"
                    placeholder="MM/YY"
                    pattern="(0[1-9]|1[0-2])\/[0-9]{2}"
                    required
                  />
                  <input
                    type="text"
                    className="checkout-input"
                    placeholder="CVV"
                    pattern="[0-9]{3}"
                    maxLength="3"
                    required
                  />
                </div>
              </div>
            )}

            {paymentMethod === "upi" && (
              <div className="checkout-section">
                <h3>Enter Your UPI ID (for records)</h3>
                <div className="input-row">
                  <input
                    type="text"
                    className="checkout-input"
                    placeholder="example@upi"
                    pattern="^[\\w.-]+@[\\w.-]+$"
                    value={customerUpiId}
                    onChange={(e) => setCustomerUpiId(e.target.value)}
                    required
                  />
                </div>

                {qrSrc && (
                  <div className="upi-payment-section">
                    <h3>Scan QR Code to Pay</h3>
                    <img
                      src={qrSrc}
                      width={220}
                      height={220}
                      alt="UPI QR Code"
                      className="upi-qr-img"
                      style={{ background: "#fff", padding: 10, borderRadius: 8 }}
                    />

                    <p>Or use these apps to pay:</p>
                    <div className="upi-app-links">
                      <a
                        href={upiLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="upi-app-link"
                      >
                        Open in UPI App
                      </a>
                      <button
                        type="button"
                        className="upi-app-link"
                        onClick={() => copy(upiLink, "UPI payment link copied!")}
                      >
                        Copy UPI Link
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Contact Info */}
            <div className="checkout-section">
              <h2>Contact Information</h2>
              <input
                type="email"
                placeholder="Email address"
                className="checkout-input"
                required
              />
            </div>

            {/* Billing Address */}
            <div className="checkout-section">
              <h2>Billing Address</h2>
              <select className="checkout-input" required>
                <option value="India">India</option>
              </select>

              <div className="input-row">
                <input
                  type="text"
                  placeholder="First name"
                  className="checkout-input"
                  required
                />
                <input
                  type="text"
                  placeholder="Last name"
                  className="checkout-input"
                  required
                />
              </div>

              <input
                type="text"
                placeholder="Address"
                className="checkout-input"
                required
              />

              <h3 className="checkout-heading">+ Add apartment, suite, etc.</h3>

<div className="input-row">
  <select className="checkout-input" required>
    <option value="">Select State</option>
    <option value="Andhra Pradesh">Andhra Pradesh</option>
    <option value="Arunachal Pradesh">Arunachal Pradesh</option>
    <option value="Assam">Assam</option>
    <option value="Bihar">Bihar</option>
    <option value="Chhattisgarh">Chhattisgarh</option>
    <option value="Goa">Goa</option>
    <option value="Gujarat">Gujarat</option>
    <option value="Haryana">Haryana</option>
    <option value="Himachal Pradesh">Himachal Pradesh</option>
    <option value="Jharkhand">Jharkhand</option>
    <option value="Karnataka">Karnataka</option>
    <option value="Kerala">Kerala</option>
    <option value="Madhya Pradesh">Madhya Pradesh</option>
    <option value="Maharashtra">Maharashtra</option>
    <option value="Manipur">Manipur</option>
    <option value="Meghalaya">Meghalaya</option>
    <option value="Mizoram">Mizoram</option>
    <option value="Nagaland">Nagaland</option>
    <option value="Odisha">Odisha</option>
    <option value="Punjab">Punjab</option>
    <option value="Rajasthan">Rajasthan</option>
    <option value="Sikkim">Sikkim</option>
    <option value="Tamil Nadu">Tamil Nadu</option>
    <option value="Telangana">Telangana</option>
    <option value="Tripura">Tripura</option>
    <option value="Uttar Pradesh">Uttar Pradesh</option>
    <option value="Uttarakhand">Uttarakhand</option>
    <option value="West Bengal">West Bengal</option>
    <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
    <option value="Chandigarh">Chandigarh</option>
    <option value="Dadra and Nagar Haveli and Daman and Diu">Dadra and Nagar Haveli and Daman and Diu</option>
    <option value="Lakshadweep">Lakshadweep</option>
    <option value="Delhi">Delhi</option>
    <option value="Puducherry">Puducherry</option>
    <option value="Ladakh">Ladakh</option>
    <option value="Jammu and Kashmir">Jammu and Kashmir</option>
  </select>

                <input
                  type="text"
                  placeholder="City"
                  className="checkout-input"
                  required
                />
              </div>

              <div className="input-row">
                <input
                  type="text"
                  placeholder="PIN Code"
                  className="checkout-input"
                  pattern="[0-9]{6}"
                  maxLength="6"
                  required
                />
                <input
                  type="tel"
                  placeholder="Phone"
                  className="checkout-input"
                  pattern="[0-9]{10}"
                  maxLength="10"
                  required
                />
              </div>
            </div>

            {/* Buttons */}
            <div className="checkout-buttons">
              <button
                type="button"
                className="back-btn"
                onClick={() => navigate("/cart")}
              >
                Return to Cart
              </button>
              <button type="submit" className="place-order-btn">
                Place Order
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Right Side - Order Summary */}
      <div className="checkout-right">
        <h2>Order summary</h2>
        {cart.map((item, index) => {
          const price = toNumber(item.price);
          const qty = Number(item.quantity) || 0;
          const line = price * qty;
          return (
            <div key={index} className="summary-item">
              <img src={item.image} alt={item.name} className="cart-img" />
              <div className="summary-details">
                <p className="summary-name">{item.name}</p>
                <p className="summary-price">₹{formatINR(price)}</p>
                <p>Qty: {qty}</p>
              </div>
              <p className="summary-line-price">₹{formatINR(line)}</p>
            </div>
          );
        })}
        <div className="summary-row summary-total">
          <span>Total</span>
          <span>₹{formatINR(totalPrice)}</span>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
