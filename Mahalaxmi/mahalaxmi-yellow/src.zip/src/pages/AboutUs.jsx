import React, { useState, useRef, useEffect } from "react";
import { useLocation } from "react-router-dom";
import "../styles/AboutUs.css";

// ✅ Import images from assets
import aboutImage from "../assets/aboutus.jpg";
import trustImage from "../assets/about.jpg"; // <-- Add your "18 Years of Trust" image here
import team1 from "../assets/teammember.jpg";
import team2 from "../assets/teammember.jpg";
import team3 from "../assets/teammember.jpg";
import team4 from "../assets/teammember.jpg";
import team5 from "../assets/teammember.jpg"; // New member image

const AboutUs = () => {
  const [showVideo, setShowVideo] = useState(false);
  const teamRef = useRef(null);

  // Team members list
  const teamMembers = [
    { img: team1, name: "Ramesh Kumar", role: "Founder & CEO" },
    { img: team2, name: "Priya Sharma", role: "Head of Operations" },
    { img: team3, name: "Amit Verma", role: "Customer Support Lead" },
    { img: team4, name: "Sunita Patel", role: "Marketing Head" },
    { img: team5, name: "Rajesh Singh", role: "Sales Manager" },
  ];

  // Create clones for infinite loop
  const extendedMembers = [
    ...teamMembers, // Original
    ...teamMembers, // Duplicate once
  ];

  // Ensure we start in the "middle" (so we can scroll both directions)
  useEffect(() => {
    if (teamRef.current) {
      teamRef.current.scrollLeft =
        teamRef.current.scrollWidth / 2 - teamRef.current.clientWidth / 2;
    }
  }, []);

  // ✅ Scroll with infinite loop
  const scroll = (direction) => {
    if (!teamRef.current) return;
    const container = teamRef.current;
    const scrollAmount = 300;

    if (direction === "left") {
      container.scrollBy({ left: -scrollAmount, behavior: "smooth" });
    } else {
      container.scrollBy({ left: scrollAmount, behavior: "smooth" });
    }

    // After scroll ends, check if we’re near an edge → reset to middle
    setTimeout(() => {
      if (container.scrollLeft <= 0) {
        container.scrollLeft =
          container.scrollWidth / 2 - container.clientWidth;
      } else if (
        container.scrollLeft + container.clientWidth >=
        container.scrollWidth
      ) {
        container.scrollLeft =
          container.scrollWidth / 2 - container.clientWidth;
      }
    }, 400); // match scroll smooth timing
  };

  return (
    <section className="about-section">
      <div className="about-container">
        {/* 🔹 Top Image Banner */}
        <div className="about-image-wrapper">
          <img
            src={aboutImage}
            alt="About Mahalaxmi Attachakki"
            className="about-image"
          />
          <button
            className="watch-video-btn"
            onClick={() => setShowVideo(true)}
          >
            ▶ Watch Video
          </button>
        </div>

        {/* 🔹 Passion Section (new) */}
        <div className="passion-section">
          <div className="passion-left">
            <img src={trustImage} alt="18 Years of Trust" />
          </div>
          <div className="passion-right">
            <h2>
              <span className="dot">●</span> Mahalaxmi The Passion
            </h2>
            <p>
              Dealing in Mahalaxmi Attachakki is not just business..
              Mahalaxmi Attachakki is our passion... we expect the same
              passion in our down channels and outlet also. We are not
              just selling Attachakki, we are sending one family to serve
              best to our valuable customer for life time.
            </p>
          </div>
        </div>

        {/* 🔹 Video Modal */}
        {showVideo && (
          <div className="video-modal">
            <span className="close-modal" onClick={() => setShowVideo(false)}>
              ✖
            </span>
            <video src="/video1.mp4" controls autoPlay />
          </div>
        )}

        {/* 🔹 Counter Section */}
        <div className="counter-section">
          <div className="counter-box">
            <h3>10+</h3>
            <p>Years of Experience</p>
          </div>
          <div className="counter-box">
            <h3>5000+</h3>
            <p>Happy Clients</p>
          </div>
          <div className="counter-box">
            <h3>50+</h3>
            <p>Cities Served</p>
          </div>
          <div className="counter-box">
            <h3>100%</h3>
            <p>Quality Assurance</p>
          </div>
        </div>

        {/* 🔹 Meet Our Team */}
        <div className="team-section" id="team">
          <h2>Meet Our Team</h2>

          {/* Arrows */}
          <button className="scroll-btn left" onClick={() => scroll("left")}>
            ←
          </button>
          <button className="scroll-btn right" onClick={() => scroll("right")}>
            →
          </button>

          <div className="team-container" ref={teamRef}>
            {extendedMembers.map((member, index) => (
              <div className="team-member" key={index}>
                <div className="team-image">
                  <img src={member.img} alt={member.name} />
                  <div className="social-icons">
                    <a href="#"><i className="fab fa-facebook-f"></i></a>
                    <a href="#"><i className="fab fa-twitter"></i></a>
                    <a href="#"><i className="fab fa-linkedin-in"></i></a>
                  </div>
                </div>
                <h4>{member.name}</h4>
                <p>{member.role}</p>
              </div>
            ))}
          </div>
        </div>

        {/* 🔹 Happy Clients */}
        <div className="clients-section">
          <h2>Our Happy Clients</h2>
          <div className="clients-container">
            <div className="client-card">
              <div className="stars">★★★★★</div>
              <h3>Customer Support</h3>
              <p>
                Customer support was amazingly fast, personal response via call
                and helped me within minutes, thank you so much!!
              </p>
              <h4>Amit Sharma</h4>
              <p className="client-role">Founder & CEO</p>
            </div>

            <div className="client-card">
              <div className="stars">★★★★★</div>
              <h3>Quality Product</h3>
              <p>
                Fresh flour at home has changed our lifestyle! The machine is
                reliable and so easy to use.
              </p>
              <h4>RAHUL VERMA</h4>
              <p className="client-role">Home Baker</p>
            </div>

            <div className="client-card">
              <div className="stars">★★★★★</div>
              <h3>Great Experience</h3>
              <p>
                Excellent quality and durable machine. The team provided amazing
                guidance during installation.
              </p>
              <h4>PRIYA SHARMA</h4>
              <p className="client-role">Health Enthusiast</p>
            </div>

            <div className="client-card">
              <div className="stars">★★★★★</div>
              <h3>Highly Recommended</h3>
              <p>
                Worth every penny! Smooth performance and professional customer
                service.
              </p>
              <h4>AMIT KUMAR</h4>
              <p className="client-role">Entrepreneur</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutUs;
