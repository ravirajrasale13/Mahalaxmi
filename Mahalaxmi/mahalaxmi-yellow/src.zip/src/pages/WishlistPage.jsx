import React from "react";
import { useWishlist } from "../context/WishlistContext";
import { useCart } from "../context/CartContext"; 
import "../styles/WishlistPage.css";

const WishlistPage = () => {
  const { wishlist, removeFromWishlist, clearWishlist } = useWishlist();
  const { addToCart } = useCart(); 

  // Helper: sanitize price once
  const sanitizePrice = (price) => {
    if (typeof price === "string") {
      const parsed = parseFloat(price.replace(/[^\d.-]/g, ""));
      return isNaN(parsed) ? 0 : parsed;
    }
    return typeof price === "number" ? price : 0;
  };

  const handleAddToCart = (item) => {
    const sanitizedItem = {
      ...item,
      price: sanitizePrice(item.price),
      quantity: 1
    };
    addToCart(sanitizedItem, 1);
  };

  return (
    <div className="wishlist-container">
      <h2>Your Wishlist</h2>

      {wishlist.length === 0 ? (
        <p className="empty-wishlist">Your wishlist is empty.</p>
      ) : (
        <>
          {wishlist.map((item) => (
            <div key={item.id} className="wishlist-item">
              {item.image && (
                <img
                  src={item.image}
                  alt={item.name}
                  className="wishlist-item-image"
                />
              )}
              <div className="wishlist-item-info">
                <strong>{item.name}</strong>
                <div>Price: ₹{sanitizePrice(item.price).toFixed(2)}</div>
              </div>
              <div className="wishlist-buttons">
                <button
                  className="add-to-cart-btn"
                  onClick={() => handleAddToCart(item)}
                >
                  Add to Cart
                </button>
                <button
                  className="remove-btn"
                  onClick={() => removeFromWishlist(item.id)}
                >
                  Remove
                </button>
              </div>
            </div>
          ))}

          <button className="clear-wishlist-btn" onClick={clearWishlist}>
            Clear Wishlist
          </button>
        </>
      )}
    </div>
  );
};

export default WishlistPage;
